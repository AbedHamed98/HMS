<?php
include("headerapi.php");
if(isset($_POST['submit']))
{
	$sql ="UPDATE  admission SET status='Active' WHERE admission_id='$_POST[admission_id]'";
	$qsql = mysqli_query($con,$sql);
	
	$sql ="UPDATE  fees SET status='Active' WHERE admission_id='$_POST[admission_id]'";
	$qsql = mysqli_query($con,$sql);
	
	$particulars = "Card Holder: $_POST[cardholder] <br> Card number: $_POST[cardnumber] <br> CVV Number: $_POST[cvvnumber] <br> Expiry Date: $_POST[month]";		
	$sql = "INSERT INTO billing(admission_id,bill_type,paid_amt,paid_date,payment_type,particulars,status)VALUES('$_POST[billid]','$_POST[bill_type]','$_POST[paid_amt]','$dt','$_POST[paymenttype]','$_POST[messbillmonth]','Active')";
	$qsql = mysqli_query($con,$sql);
	echo mysqli_error($con);
	$insid=mysqli_insert_id($con);
	if(mysqli_affected_rows($con) ==1 )
	{
		echo json_encode(array('billid' => $_POST['billid'], 'month' => $_POST['month']));
	}
}
?>