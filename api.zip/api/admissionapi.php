<?php
include("headerapi.php");
$dt=date("Y-m-d");
if(isset($_POST['submitadmission']))
{
	$sql ="INSERT INTO admission(hostellerid,room_id,start_date,end_date,food_type,status)VALUES('$_POST[hostellerid]','$_POST[room_id]','$_POST[start_date]','$_POST[end_date]','$_POST[food_type]','Pending')";
	$qsql = mysqli_query($con,$sql);		
	$insid= mysqli_insert_id($con);		
	$sql = "INSERT INTO fees(admission_id,fee_str_id,total_fees,invoice_date,status) VALUES('$insid','$_POST[fee_str_id]','$_POST[cost]','$dt','Pending')";
	$qsql = mysqli_query($con,$sql);
	if(mysqli_affected_rows($con) ==1 )
	{
		echo $insid;
	}
	else
	{
		echo mysqli_error($con);
	}
}
?>