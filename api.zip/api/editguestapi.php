<?php
include("headerapi.php");
if(isset($_POST['submit']))
{
	if(isset($_POST['editid']))
	{
		//Update statement starts here
		 $sql ="UPDATE guest SET name='$_POST[name]',visitreason='$_POST[visitreason]',emailid='$_POST[emailid]',contactno='$_POST[contactno]',comment='$_POST[comment]',fromdate='$_POST[fromdate]',todate='$_POST[todate]',status='Active' WHERE  guestid='" . $_POST['editid'] . "'";
		$qsql = mysqli_query($con,$sql);
		if(mysqli_affected_rows($con) ==1 )
		{
			                    			echo json_encode(1);

		}
		else
		{
                    			echo json_encode(0);
		}
		//Update statement ends here		
	}
	else
	{

if ($stmt = $con->prepare('SELECT guestid, password FROM guest WHERE emailid = ?')) {
	// Bind parameters (s = string, i = int, b = blob, etc), hash the password using the PHP password_hash function.
	$stmt->bind_param('s', $_POST['emailid']);
	$stmt->execute();
	$stmt->store_result();
	// Store the result so we can check if the account exists in the database.
	if ($stmt->num_rows > 0) {
		// Username already exists
					                    			echo json_encode(0);

	} else {
		// Insert new account
		// Username doesnt exists, insert new account

	
if ($stmt = $con->prepare('INSERT INTO guest (gender, contactno, status ,name, password, emailid, activation_code) VALUES (?, ?, ?, ?, ?, ?, ?)')) {
	// We do not want to expose passwords in our database, so hash the password and use password_verify when a user logs in.
	$password = password_hash($_POST['password'], PASSWORD_DEFAULT);
	$uniqid = uniqid();
	$stat = 'Inactive';

$stmt->bind_param('sssssss', $_POST['gender'], $_POST['contactno'], $stat, $_POST['name'], $password, $_POST['emailid'], $uniqid);

	$stmt->execute();
$from    = 'noreply@yourdomain.com';
$subject = 'Account Activation Required';
$headers = 'From: ' . $from . "\r\n" . 'Reply-To: ' . $from . "\r\n" . 'X-Mailer: PHP/' . phpversion() . "\r\n" . 'MIME-Version: 1.0' . "\r\n" . 'Content-Type: text/html; charset=UTF-8' . "\r\n";
// Update the activation variable below
$hashed = 'you password' . $_POST['password'];
$activate_link = 'http://192.168.8.102/EHOSTEL/activate.php?emailid=' . $_POST['emailid'] . '&code=' . $uniqid;
$message = '<p>Please click the following link to activate your account: <a href="' . $activate_link . '">' . $activate_link . '</a>  <a href="' . $password . '">' . $hashed . '</a>	</p>';
mail($_POST['emailid'], $subject, $message, $headers);

echo "<script>viewmessagebox('Please check your emailid to activate your account!....','index.php')</script>";
}
 else {
	// Something is wrong with the sql statement, check to make sure accounts table exists with all 3 fields.
                    			echo json_encode(0);

}
	}
	$stmt->close();
} else {
	// Something is wrong with the sql statement, check to make sure accounts table exists with all 3 fields.
                    			echo json_encode(0);

}
$con->close();



}
}

if(isset($_POST['viewguestid']))
{
	$sqledit = "SELECT * FROM guest WHERE guestid='" . $_POST['viewguestid'] . "'";
	$qsqledit = mysqli_query($con,$sqledit);
	$rsedit = mysqli_fetch_array($qsqledit);
	echo json_encode($rsedit);
}
?>