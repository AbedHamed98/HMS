


		<?php
include("headerapi.php");
	 $sql ="UPDATE employee SET emp_name='$_POST[emp_name]',login_id='$_POST[login_id]',emp_type='$_POST[emp_type]',password='$_POST[password]',gender='$_POST[gender]',designation='$_POST[designation]',status='$_POST[status]'";
		$qsql = mysqli_query($con,$sql);
		if(mysqli_affected_rows($con) ==1 )
		{

                    			echo json_encode(1);
		}
		else
		{
                    			echo json_encode(0);
		}
$qsql = mysqli_query($con,$sql);
while($rs = mysqli_fetch_array($qsql))
{
	$arrec[] = $rs;
}
echo json_encode($arrec);


?>