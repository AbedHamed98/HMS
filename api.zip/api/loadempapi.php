<?php 
include("headerapi.php");

if(isset($_POST['loadreply']))
{
	$sql ="SELECT  * from employee  WHERE emp_id='$_POST[emp_id]'";
	$qsql = mysqli_query($con,$sql);
$rs = mysqli_fetch_array($qsql);
echo json_encode($rs);
}


 ?>