<?php
include("headerapi.php");
$sql ="SELECT * FROM fees_structure WHERE status='Active' AND hostellertype='$_POST[hostellertype]' AND block_id='$_POST[block_id]'";
$qsql = mysqli_query($con,$sql);
while($rs = mysqli_fetch_array($qsql))
{
	$arrec[] = $rs;
}
echo json_encode($arrec);
?>