<?php
include("headerapi.php");
if(isset($_POST['submit']))
{
	if(isset($_POST['editid']))
	{
		//Update statement starts here
		 $sql ="UPDATE employee SET emp_name='$_POST[emp_name]',login_id='$_POST[login_id]',emp_type='$_POST[emp_type]',password='$_POST[password]',gender='$_POST[gender]',designation='$_POST[designation]',status='$_POST[status]'WHERE  emp_id='" . $_POST['editid'] . "'";
		$qsql = mysqli_query($con,$sql);
		if(mysqli_affected_rows($con) ==1 )
		{

                    			echo json_encode(1);
		}
		else
		{
                    			echo json_encode(0);
		}
		//Update statement ends here		
	
}
	else
	{
	if ($emp = $con->prepare('SELECT emp_id, password FROM employee WHERE login_id = ?')) {
    // Bind parameters (s = string, i = int, b = blob, etc), hash the password using the PHP password_hash function.
    $emp->bind_param('s', $_POST['login_id']);
    $emp->execute();
    $emp->store_result();
    // Store the result so we can check if the account exists in the database.
    if ($emp->num_rows > 0) {
        // Useremp_name already exists
                    			echo json_encode(0);

    } else {
        // Insert new account
        // Useremp_name doesnt exists, insert new account

    
if ($emp = $con->prepare('INSERT INTO employee (emp_type, designation, gender, status, emp_name, password, login_id, activation_code) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')) {
    // We do not want to expose passwords in our database, so hash the password and use password_verify when a user logs in.
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $uniqid = uniqid();
    $stat = 'Active';

$emp->bind_param('ssssssss', $_POST['emp_type'], $_POST['designation'], $_POST['gender'], $stat, $_POST['emp_name'], $password, $_POST['login_id'], $uniqid);

    $emp->execute();
$from    = 'noreply@yourdomain.com';
$subject = 'Account Activation Required';
$headers = 'From: ' . $from . "\r\n" . 'Reply-To: ' . $from . "\r\n" . 'X-Mailer: PHP/' . phpversion() . "\r\n" . 'MIME-Version: 1.0' . "\r\n" . 'Content-Type: text/html; charset=UTF-8' . "\r\n";
// Update the activation variable below
$hashed = 'you password' . $_POST['password'];
$activate_link = 'http://192.168.8.102/EHOSTEL/empactivate.php?login_id=' . $_POST['login_id'] . '&code=' . $uniqid;
$message = '<p>Please click the following link to activate your account: <a href="' . $activate_link . '">' . $activate_link . '</a>  <a href="' . $password . '">' . $hashed . '</a>   </p>';
mail($_POST['login_id'], $subject, $message, $headers);

echo "<script>viewmessagebox('Please check your login_id to activate your account!....','index.php')</script>";
}
 else {
    // Something is wrong with the sql statement, check to make sure accounts table exists with all 3 fields.
                    			echo json_encode(0);

}
    }
    $emp->close();
} else {
    // Something is wrong with the sql statement, check to make sure accounts table exists with all 3 fields.
                    			echo json_encode(0);

}
$con->close();

}
}

if(isset($_POST['viewguestid']))
{
	$sqledit = "SELECT * FROM employee WHERE emp_id='" . $_POST['viewguestid'] . "'";
	$qsqledit = mysqli_query($con,$sqledit);
	$rsedit = mysqli_fetch_array($qsqledit);
	echo json_encode($rsedit);
}
?>