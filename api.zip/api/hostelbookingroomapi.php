<?php
include("headerapi.php");
if(isset($_POST['get_fees_structure']))
{
$sqlfees_structure ="SELECT * FROM fees_structure WHERE status='Active' AND hostellertype='$_POST[hostellertype]' AND fee_str_id='$_POST[fee_str_id]'";
$qsqlfees_structure = mysqli_query($con,$sqlfees_structure);
$rsfees_structure = mysqli_fetch_array($qsqlfees_structure);
echo json_encode($rsguestfees_structure);
}
if(isset($_POST['get_hostel_info']))
{
//##############
$sqlblocks ="SELECT * FROM blocks WHERE status='Active' AND block_id='$_POST[block_id]'";
$qsqlblocks = mysqli_query($con,$sqlblocks);
$rsblocks = mysqli_fetch_array($qsqlblocks);
echo json_encode($rsblocks);
//##############
}
if(isset($_POST['btn_booking_panel']))
{
	$countbooking=0;
	$sqladmission = "SELECT * FROM admission WHERE ('$dt' BETWEEN start_date AND end_date) AND admission.status='Active' AND hostellerid='" . $_POST['hostellerid'] . "'";
	$qsqladmission = mysqli_query($con,$sqladmission);
	if(mysqli_num_rows($qsqladmission) >=1)
	{
		$rsadmission = mysqli_fetch_array($qsqladmission);
		$sqlbilling = "SELECT * FROM billing WHERE admission_id='$rsadmission[0]'";
		$qsqlbilling = mysqli_query($con,$sqlbilling);
		echo mysqli_error($con);
		$countbooking = mysqli_num_rows($qsqlbilling);
		$rsbilling = mysqli_fetch_array($qsqlbilling);
	}
	$sql ="SELECT * FROM room WHERE status='Active'  AND block_id='$_POST[block_id]' AND fee_str_id='$_POST[fee_str_id]'";
	$qsql = mysqli_query($con,$sql);
	echo mysqli_error($con);
	while($rs = mysqli_fetch_array($qsql))
	{
		$sqladmission = "SELECT * FROM admission WHERE room_id='$rs[room_id]' AND (('$dt' BETWEEN start_date AND end_date) OR (start_date>'$dt')) AND status='Active'";
		$qsqladmission = mysqli_query($con,$sqladmission);
		$rsadmission = mysqli_fetch_array($qsqladmission);
		$admissionnumrows = mysqli_num_rows($qsqladmission);
	?>
			<?php
			for($i=0; $i<$rs['no_of_beds'];$i++)
			{
				if($admissionnumrows > $i)
				{
					echo json_encode(array('a' => $rs, 'status' => "booked",'alreadybooked'=>$countbooking));
				}
				else
				{
					echo json_encode(array('a' => $rs, 'status' => "available",'alreadybooked'=>$countbooking));
				}
			}
			?>
	<?php
	}
	?>
<?php
}
?>