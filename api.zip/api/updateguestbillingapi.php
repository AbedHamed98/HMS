<?php
include("headerapi.php");
if(isset($_POST['submit']))
{
	//Update statement starts here
	$sql ="UPDATE guestbilling SET status='$_POST[status]' WHERE  billid='$_POST[billid]'";
	$qsql = mysqli_query($con,$sql);
	if(mysqli_affected_rows($con) ==1 )
	{
	echo json_encode(1);
	}
	else
	{
	echo json_encode(0);
	}
	//Update statement ends here		
}
?>