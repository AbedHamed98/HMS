<?php 
if(isset($_POST['viewhostellerid']))
{
	$sqledit = "SELECT * FROM  hosteller WHERE hostellerid='$_POST[viewhostellerid]'";
	$qsqledit = mysqli_query($con,$sqledit);
	$rsguestfees_structure = mysqli_fetch_array($qsqledit);
	echo json_encode($rsguestfees_structure);
}

 ?>