

<?php
include("headerapi.php");

	
if(isset($_POST['viewguestid']))
{
	$sqledit = "SELECT * FROM admission LEFT JOIN hosteller ON admission.hostellerid=hosteller.hostellerid LEFT JOIN room ON room.room_id=admission.room_id WHERE admission.admission_id='" . $_POST['viewguestid'] . "'";

	$qsqledit = mysqli_query($con,$sqledit);
	$rsguestfees_structure = mysqli_fetch_array($qsqledit);
	echo json_encode($rsguestfees_structure);
}

?>