<?php
include("headerapi.php");
if(isset($_POST['submit']))
{
	//Update statement starts here
	$sql ="UPDATE employee SET emp_name='$_POST[emp_name]',login_id='$_POST[login_id]',designation='$_POST[designation]' WHERE  emp_id='$_POST[emp_id]'";
	$qsql = mysqli_query($con,$sql);
	if(mysqli_affected_rows($con) ==1 )
	{
	echo json_encode(1);
	}
	else
	{
	echo json_encode(0);
	}
	//Update statement ends here		
}
?>