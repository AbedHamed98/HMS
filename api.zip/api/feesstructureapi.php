<?php
include("headerapi.php");
$sqlguestfees_structure = "SELECT * FROM fees_structure WHERE hostellertype='Guest'";
$qsqlguestfees_structure = mysqli_query($con,$sqlguestfees_structure);
$rsguestfees_structure = mysqli_fetch_array($qsqlguestfees_structure);
echo json_encode($rsguestfees_structure);
?>