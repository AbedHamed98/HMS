

<?php
include("headerapi.php");
if(isset($_POST['submit']))
{
	//Update statement starts here
	$sql ="UPDATE fees_structure SET room_type='$_POST[room_type]', hostellertype='$_POST[hostellertype]',hostellergender='$_POST[hostellergender]', block_id='$_POST[block_id]', Style='$_POST[Style]',cost='$_POST[cost]',status='$_POST[status]' WHERE  fee_str_id='$_POST[fee_str_id]'"
	$qsql = mysqli_query($con,$sql);
	if(mysqli_affected_rows($con) ==1 )
	{
	echo json_encode(1);
	}
	else
	{
	echo json_encode(0);
	}
	//Update statement ends here		
}
?>