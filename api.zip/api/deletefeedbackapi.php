<?php 

include("headerapi.php");

if(isset($_POST[feedback_id]))
{
	$sqledit = "DELETE FROM feedback WHERE feedback_id='$_POST[feedback_id]'";
	$qsqledit = mysqli_query($con,$sqledit);
	$rsedit = mysqli_fetch_array($qsqledit);
	echo json_encode($rsedit);
		
}

 ?>