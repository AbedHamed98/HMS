
<?php
include("headerapi.php");
	$sql ="SELECT * FROM employee";
$qsql = mysqli_query($con,$sql);
while($rs = mysqli_fetch_array($qsql))
{
	$arrec[] = $rs;
}
echo json_encode($arrec);


?>
