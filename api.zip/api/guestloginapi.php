<?php
include("headerapi.php");
if(isset($_POST['submit']))
{	$password = $_POST[password];
	$sql ="SELECT * FROM guest WHERE emailid='$_POST[login_id]'  AND status='Active'";
	$qsql=mysqli_query($con,$sql);
	echo mysqli_error($con);
	$rs= mysqli_fetch_array($qsql);

	if(mysqli_num_rows($qsql)==1)
	{
		if (password_verify($password, $rs['password'])) {
		
		echo json_encode($rs);
	}
	else
	{
		echo json_encode(0);
	}
}
}

?>


