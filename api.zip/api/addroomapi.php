<?php
include("headerapi.php");
if(isset($_POST['submit']))
{
	if(isset($_POST[room_id]))
	{
	$sql = "INSERT INTO room(block_id,fee_str_id,room_no,no_of_beds,hostellergender,description,status) VALUES('$_POST[block_id]','$_POST[fee_str_id]','$_POST[room_no]','$_POST[no_of_beds]','$_POST[hostellergender]','$_POST[description]','$_POST[status]')";
	$qsql = mysqli_query($con,$sql);
	if(mysqli_affected_rows($con) ==1 )
	{
				                     			echo json_encode(1);

	}
	else
	{
		                     			echo json_encode(0);
	}
	}
	else
	{
		$sql ="UPDATE room SET room_no='$_POST[room_no]',fee_str_id='$_POST[fee_str_id]',hostellergender='$_POST[hostellergender]', block_id='$_POST[block_id]', no_of_beds='$_POST[no_of_beds]',description='$_POST[description]',status='$_POST[status]' WHERE  room_id='$_POST[room_id]'";
		$qsql = mysqli_query($con,$sql);
		if(mysqli_affected_rows($con) ==1 )
		{
		                     			echo json_encode(1);

		} else{
		                     			echo json_encode(0);
		}
	
}
}
if(isset($_POST['viewguestid']))
{
	$sqledit = "SELECT * FROM room,blocks,fees_structure WHERE room.fee_str_id = fees_structure.fee_str_id AND blocks.block_id = room.block_id AND room_id='" . $_POST['viewguestid'] . "'";
	$qsqledit = mysqli_query($con,$sqledit);
	$rsedit = mysqli_fetch_array($qsqledit);
		echo json_encode($rsedit);

}
?>