<?php
include("headerapi.php");
if(isset($_POST['submit']))
{
	if(isset($_POST['editid']))
	{
		//Update statement starts here
		$sql ="UPDATE hosteller SET hostellertype='$_POST[hostellertype]',name='$_POST[name]',emailid='$_POST[emailid]',password='$_POST[password]',dob='$_POST[dob]',father_name='$_POST[father_name]',mother_name='$_POST[mother_name]',address='$_POST[address]',contact_no='$_POST[contact_no]',status='Active' WHERE hostellerid='" . $_POST['editid'] . "'";
		$qsql = mysqli_query($con,$sql);
		if(mysqli_affected_rows($con) ==1 )
		{
			echo json_encode(1);
		}
		else
		{
			echo json_encode(0);
		}
		//Update statement ends here		
	}
	else
	{
	if ($emp = $con->prepare('SELECT hostellerid, password FROM hosteller WHERE emailid = ?')) {
    // Bind parameters (s = string, i = int, b = blob, etc), hash the password using the PHP password_hash function.
    $emp->bind_param('s', $_POST['emailid']);
    $emp->execute();
    $emp->store_result();
    // Store the result so we can check if the account exists in the database.
    if ($emp->num_rows > 0) {
        // Username already exists
                    			echo json_encode(0);


    } else {
        // Insert new account
        // Username doesnt exists, insert new account

    
if ($emp = $con->prepare('INSERT INTO hosteller (dob, mother_name, father_name, contact_no, hostellertype, address, hostellergender, status, name, password, emailid, activation_code) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')) {
    // We do not want to expose passwords in our database, so hash the password and use password_verify when a user logs in.
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $uniqid = uniqid();
    $stat = 'Inactive';

$emp->bind_param('ssssssssssss', $_POST['dob'],$_POST['mother_name'], $_POST['father_name'], $_POST['contact_no'], $_POST['hostellertype'], $_POST['address'], $_POST['hostellergender'], $stat, $_POST['name'], $password, $_POST['emailid'], $uniqid);

    $emp->execute();
$from    = 'noreply@yourdomain.com';
$subject = 'Account Activation Required';
$headers = 'From: ' . $from . "\r\n" . 'Reply-To: ' . $from . "\r\n" . 'X-Mailer: PHP/' . phpversion() . "\r\n" . 'MIME-Version: 1.0' . "\r\n" . 'Content-Type: text/html; charset=UTF-8' . "\r\n";
// Update the activation variable below
$hashed = 'you password' . $_POST['password'];
$activate_link = 'http://192.168.8.102/EHOSTEL/hostelleractivate.php?emailid=' . $_POST['emailid'] . '&code=' . $uniqid;
$message = '<p>Please click the following link to activate your account: <a href="' . $activate_link . '">' . $activate_link . '</a>  <a href="' . $password . '">' . $hashed . '</a>   </p>';
mail($_POST['emailid'], $subject, $message, $headers);

echo "<script>viewmessagebox('Please check your emailid to activate your account!....','index.php')</script>";
}
 else {
    // Something is wrong with the sql statement, check to make sure accounts table exists with all 3 fields.
           			echo json_encode(0);


}
    }
    $emp->close();
} else {
    // Something is wrong with the sql statement, check to make sure accounts table exists with all 3 fields.
           			echo json_encode(0);


}
$con->close();

}
}
if(isset($_POST['viewguestid']))
{
	$sqledit = "SELECT * FROM  hosteller WHERE hostellerid='" . $_POST['viewguestid'] . "'";
	$qsqledit = mysqli_query($con,$sqledit);
	$rsguestfees_structure = mysqli_fetch_array($qsqledit);
	echo json_encode($rsguestfees_structure);
}
?>