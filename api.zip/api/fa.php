<?php 
include ("headerapi.php");

$sql = "SELECT * FROM fees_structure LEFT JOIN blocks ON fees_structure.block_id= blocks.block_id";
$qsql = mysqli_query($con,$sql);
	while($rs = mysqli_fetch_array($qsql))
{
	$arrec[] = $rs;
}
echo json_encode($arrec);
?>