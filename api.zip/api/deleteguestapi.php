
<?php 

include("headerapi.php");

if(isset($_POST['delid']))
{
	$sqledit = "DELETE FROM guest WHERE guestid='" . $_POST['delid'] . "'";
	$qsqledit = mysqli_query($con,$sqledit);
	$rsedit = mysqli_fetch_array($qsqledit);
	echo json_encode($rsedit);
		
}



 ?>
