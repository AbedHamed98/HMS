<?php
include("headerapi.php");
if(isset($_POST['submit']))
{
	$password = $_POST[password];
	$sql ="SELECT * FROM employee WHERE login_id='$_POST[login_id]'  AND status='Active' AND emp_type='Admin'";
	$qsql=mysqli_query($con,$sql);
	echo mysqli_error($con);
	$rs= mysqli_fetch_array($qsql);

	if(mysqli_num_rows($qsql)==1)
	{
		if (password_verify($password, $rs['password'])) {
		echo json_encode($rs);
	}
	else
	{
		echo json_encode(0);
	}
}
}
?>