<?php
include("headerapi.php");
$emp = '36';
if(isset($_POST['submit']))
{
	$dttime = date("Y-m-d H:i:s");
	$sql = "INSERT INTO reply(emp_id,hostellerid,replydttime,replysubject,replymessage) VALUES($emp,'$_POST[hostellerid]','$dttime','$_POST[replysubject]','$_POST[replymessage]')";
	$qsql = mysqli_query($con,$sql);
		echo mysqli_error($con);
	if(mysqli_affected_rows($con) ==1 )
	{
	echo 1;
	}
}
?>