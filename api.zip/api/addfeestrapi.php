<?php
include("headerapi.php");
if(isset($_POST['submit']))
{
	if(isset($_POST['editid']))
	{
		//Update statement starts here
		 $sql ="UPDATE fees_structure SET block_id='$_POST[block_id]',hostellertype='$_POST[hostellertype]',hostellergender='$_POST[hostellergender]',room_type='$_POST[room_type]',cost='$_POST[cost]',status='$_POST[status]'WHERE  fee_str_id='" . $_POST['editid'] . "'";
		$qsql = mysqli_query($con,$sql);
		if(mysqli_affected_rows($con) ==1 )
		{
					                echo json_encode(1);

		}
		else{
		                     			echo json_encode(0);
		}
	}
	else
	{
		$sql = "INSERT INTO fees_structure(block_id,hostellertype,hostellergender,Style,room_type,cost,status)VALUES('$_POST[block_id]','$_POST[hostellertype]','$_POST[hostellergender]','$_POST[Style]','$_POST[room_type]','$_POST[cost]','$_POST[status]')";
		$qsql = mysqli_query($con,$sql);
			echo mysqli_error($con);
		if(mysqli_affected_rows($con) ==1 )
		{
							              	echo json_encode(1);

			
		}
		else
		{
		                     			echo json_encode(0);
		}
	}
}
if(isset($_POST['viewguestid']))
{
	$sqledit = "SELECT * FROM fees_structure WHERE fee_str_id='" . $_POST['viewguestid'] . "'";
	$qsqledit = mysqli_query($con,$sqledit);
	$rsedit = mysqli_fetch_array($qsqledit);
}
?>