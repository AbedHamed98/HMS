<?php
include("headerapi.php");
if(isset($_POST['submit']))
{
	if(isset($_POST[mess_bill_id]))
	{
				$dd = date("Y-m-01");	
		$sql = "INSERT INTO mess_bill(admission_id,charge_type,date,mess_bill,note,status) VALUES('0','Room rent','$dd','$_POST[varroomrent]','','Charges')";
		$qsql = mysqli_query($con,$sql);
		
		$sql = "INSERT INTO mess_bill(admission_id,charge_type,date,mess_bill,note,status) VALUES('0','Mess Bill','$dd','$_POST[varmessbill]','','Charges')";
		$qsql = mysqli_query($con,$sql);
		
		$sql = "INSERT INTO mess_bill(admission_id,charge_type,date,mess_bill,note,status) VALUES('0','Water Electricity','$dd','$_POST[varwaterelectricity]','','Charges')";
		$qsql = mysqli_query($con,$sql);
		
		$sql = "INSERT INTO mess_bill(admission_id,charge_type,date,mess_bill,note,status) VALUES('0','Maintenance','$dd','$_POST[varmaintanance]','','Charges')";
		$qsql = mysqli_query($con,$sql);
		
		$sql = "INSERT INTO mess_bill(admission_id,charge_type,date,mess_bill,note,status) VALUES('0','Total Charges','$dd','$_POST[vartotal]','','Charges')";
		$qsql = mysqli_query($con,$sql);
		
		$admission_id = $_POST['admission_id'];
		$noofdaysinmonth = $_POST['noofdaysinmonth'];
		$absent = $_POST['absent'];
		$roomrent = $_POST['roomrent'];
		$messbill = $_POST['messbill'];
		$waterelectricity = $_POST['waterelectricity'];
		$maintanance = $_POST['maintanance'];
		$totalamt = $roomrent + $messbill + $waterelectricity + $maintanance;
		$lastdate = date("Y-m-01");	
		$note = $_POST['note'];
		
		
			$sql = "INSERT INTO mess_bill(admission_id,charge_type,date,mess_bill,note,status) VALUES('$_POST[admission_id]','Room Rent','$lastdate','$roomrent','$note','Active')";
			$qsql = mysqli_query($con,$sql);
			echo mysqli_error($con);
			$sql = "INSERT INTO mess_bill(admission_id,charge_type,date,mess_bill,note,status) VALUES('$_POST[admission_id]','Mess Bill','$lastdate','$messbill','$note','Active')";
			$qsql = mysqli_query($con,$sql);
			echo mysqli_error($con);
			$sql = "INSERT INTO mess_bill(admission_id,charge_type,date,mess_bill,note,status) VALUES('$_POST[admission_id]','Water Electricity','$lastdate','$waterelectricity','$note','Active')";
			$qsql = mysqli_query($con,$sql);
			echo mysqli_error($con);
			$sql = "INSERT INTO mess_bill(admission_id,charge_type,date,mess_bill,note,status) VALUES('$_POST[admission_id]','Maintenance','$lastdate','$maintanance','$note','Active')";
			$qsql = mysqli_query($con,$sql);
			echo mysqli_error($con);
			$sql = "INSERT INTO mess_bill(admission_id,charge_type,date,mess_bill,note,status) VALUES('$_POST[admission_id]','Total Charges','$lastdate','$totalamt','$note','Active')";
			$qsql = mysqli_query($con,$sql);
			echo mysqli_error($con);
	
	}
	else
	{	

		$dttime = date("Y-m-d");

	 $sql ="UPDATE mess_bill SET admission_id='$_POST[admission_id]',charge_type='$_POST[charge_type]',date='$dttime',mess_bill='$_POST[mess_bill]',note='$_POST[note]',status='$_POST[status]' WHERE  mess_bill_id='$_POST[mess_bill_id]'";
		$qsql = mysqli_query($con,$sql);
		if(mysqli_affected_rows($con) ==1 )
		{
					                     			echo json_encode(1);

		}
		else
		{
		                     			echo json_encode(0);
		}

	}
}
if(isset($_POST['viewguestid']))
{
	$sqledit = "SELECT * FROM admission LEFT JOIN hosteller ON admission.hostellerid=hosteller.hostellerid WHERE admission.status='Active' AND admission.admission_id='" . $_POST['viewguestid'] . "'";
	$qsqledit = mysqli_query($con,$sqledit);
	$rsedit = mysqli_fetch_array($qsqledit);
		echo json_encode($rsedit);

}
?>