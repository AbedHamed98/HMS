<?php
include("headerapi.php");
$dt = date("Y-m-d");
$result=array();
if(isset($_POST['submitpayment']))
{
	$sql ="UPDATE  admission SET status='Active' WHERE admission_id='$_POST[admission_id]'";
	$qsql = mysqli_query($con,$sql);
	$sql ="UPDATE  fees SET status='Active' WHERE admission_id='$_POST[admission_id]'";
	$qsql = mysqli_query($con,$sql);
	$particulars = "Card Holder: $_POST[cardholder] <br> Card number: $_POST[cardnumber] <br> CVV Number: $_POST[cvvnumber] <br> Expiry Date: $_POST[month]";		
	$sql = "INSERT INTO billing(admission_id,bill_type,paid_amt,paid_date,payment_type,particulars,status)VALUES('$_POST[admission_id]','$_POST[bill_type]','$_POST[paid_amt]','$dt','$_POST[paymenttype]','$particulars','Active')";
	$qsql = mysqli_query($con,$sql);
	echo mysqli_error($con);
	$insid=mysqli_insert_id($con);
	if(mysqli_affected_rows($con) ==1 )
	{
		echo $insid;
	}
}
if(isset($_POST['admission_id']))
{
	$sqledit ="SELECT * FROM billing WHERE admission_id='$_POST[admission_id]'";
	$qsqledit = mysqli_query($con,$sqledit);
	$rsedit = mysqli_fetch_array($qsqledit);
	$result['billing'] = $rsedit;
	$sqladmission = "SELECT * FROM admission LEFT JOIN room ON admission.room_id=room.room_id LEFT JOIN fees_structure ON fees_structure.fee_str_id=room.fee_str_id WHERE admission.admission_id='$_POST[admission_id]'";
	$qsqladmission = mysqli_query($con,$sqladmission);
	$rsadmission = mysqli_fetch_array($qsqladmission);
	$result['admission'] = $rsadmission;
	echo json_encode($result);
}
?>