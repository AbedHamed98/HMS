<?php
include("headerapi.php");
if(isset($_POST['submit']))
{
	//Update statement starts here
	$sql ="UPDATE fees_structure SET block_id='$_POST[block_id]',hostellergender='$_POST[hostellergender]', Style='$_POST[Style]',hostellertype='$_POST[hostellertype]',room_type='$_POST[room_type]',cost='$_POST[cost]',status='$_POST[status]',  WHERE  block_id='$_POST[fee_str_id]'";
	$qsql = mysqli_query($con,$sql);
	if(mysqli_affected_rows($con) ==1 )
	{
	echo json_encode(1);
	}
	else
	{
	echo json_encode(0);
	}
	//Update statement ends here		
}
?>
