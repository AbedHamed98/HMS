<?php
include("headerapi.php");
$result=array();
$sqlbilling = "SELECT * FROM billing WHERE billid='$_POST[insid]'";
$qsqlbilling = mysqli_query($con,$sqlbilling);
echo mysqli_error($con);
$rsbilling = mysqli_fetch_array($qsqlbilling);
$result['billing'] = $rsbilling;
$sqladmission = "SELECT admission.*,hosteller.*,room.* FROM admission LEFT JOIN hosteller on admission.hostellerid=hosteller.hostellerid LEFT JOIN room ON room.room_id=admission.room_id WHERE admission.admission_id='$rsbilling[admission_id]'";
$qsqladmission = mysqli_query($con,$sqladmission);
echo mysqli_error($con);
$rsadmission = mysqli_fetch_array($qsqladmission);
$result['admission'] = $rsadmission;
echo json_encode($result);
?>