<?php
include("headerapi.php");
	if(isset($_POST['editid']))
{
	//Update statement starts here
	  $sql ="UPDATE guest SET name='$_POST[name]',visitreason='$_POST[visitreason]',emailid='$_POST[emailid]',password='$_POST[password]',contactno='$_POST[contactno]',comment='$_POST[comment]',fromdate='$_POST[fromdate]',todate='$_POST[todate]',status='$_POST[status]' WHERE  guestid='" . $_POST['editid'] . "'";
	$qsql = mysqli_query($con,$sql);
	if(mysqli_affected_rows($con) ==1 )
	{
	echo json_encode(1);
	}
	else
	{
	echo json_encode(0);
	}
	//Update statement ends here		
}
?>