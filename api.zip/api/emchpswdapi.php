<?php
include("headerapi.php");
if(isset($_POST['submit']))
{
	$newhash = password_hash($_POST['password'], PASSWORD_DEFAULT);

	$sql = "UPDATE employee SET password='$newhash' WHERE emp_id='$_POST[emp_id]' ";
	$qsql = mysqli_query($con,$sql);
	echo mysqli_error($con);
	if(mysqli_affected_rows($con) ==1 )
	{
	echo json_encode(1);
	}
	else
	{
	echo json_encode(0);
	}
}
?>