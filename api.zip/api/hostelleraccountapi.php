<?php
include("headerapi.php");
function getWorkingDays($startDate,$endDate){
  $startDate = strtotime($startDate);
  $endDate = strtotime($endDate);

  if($startDate <= $endDate){
    $datediff = $endDate - $startDate;
    return floor($datediff / (60 * 60 * 24));
  }
  return false;
}
if(isset($_POST['load_admission_detail']))
{
$sql ="SELECT * FROM admission LEFT JOIN hosteller ON admission.hostellerid=hosteller.hostellerid LEFT JOIN room ON room.room_id=admission.room_id LEFT JOIN fees_structure ON fees_structure.fee_str_id=room.fee_str_id LEFT JOIN blocks on blocks.block_id=fees_structure.block_id WHERE admission.status='Active' AND ('$dt' BETWEEN admission.start_date AND admission.end_date) AND  hosteller.hostellerid='" . $_POST['hostellerid'] . "'  Order by admission_id DESC limit 0,1";
$qsql = mysqli_query($con,$sql);
$rs = mysqli_fetch_array($qsql);
echo json_encode($rs);
}
?>
<?php 
include("headerapi.php");

if(isset($_POST['loadreply']))
{
	$sql ="SELECT  * from reply LEFT JOIN employee ON reply.emp_id=employee.emp_id WHERE reply.hostellerid='$_POST[hostellerid]' Order by replydttime DESC";
	$qsql = mysqli_query($con,$sql);
$rs = mysqli_fetch_array($qsql);
echo json_encode($rs);
}


 ?>
<?php
if(isset($_POST['load_mess_bill_detail']))
{
	$sqlmess_bill = "SELECT date FROM `mess_bill` LEFT JOIN admission ON admission.admission_id=mess_bill.admission_id WHERE admission.hostellerid='" . $_POST['hostellerid'] . "' GROUP BY date ORDER BY date DESC  limit 0,1";
	$qsqlmess_bill = mysqli_query($con,$sqlmess_bill);
	while($rsmess_bill = mysqli_fetch_array($qsqlmess_bill))
	{
		$_GET['month'] = date('Y-m', strtotime("+0 month", strtotime($rsmess_bill[0])));
		$fmonth = $_GET['month']."-01";
		$tmonth = $_GET['month']."-31";
		$sql ="SELECT admission.admission_id, hosteller.name, hosteller.hostellertype,(SELECT mess_bill.mess_bill FROM mess_bill WHERE admission_id=admission.admission_id AND charge_type='Room Rent' AND status='Active' AND mess_bill.date BETWEEN '$fmonth' and '$tmonth'  limit 0,1) as roomrent,(SELECT mess_bill.mess_bill FROM mess_bill WHERE admission_id=admission.admission_id AND charge_type='Mess Bill' AND status='Active' AND mess_bill.date BETWEEN '$fmonth' and '$tmonth' limit 0,1) as messbill,(SELECT mess_bill.mess_bill FROM mess_bill WHERE admission_id=admission.admission_id AND charge_type='Water Electricity' AND status='Active' AND mess_bill.date BETWEEN '$fmonth' and '$tmonth'  limit 0,1) as waterelectricity,(SELECT mess_bill.mess_bill FROM mess_bill WHERE admission_id=admission.admission_id AND charge_type='Maintenance' AND status='Active' AND mess_bill.date BETWEEN '$fmonth' and '$tmonth' limit 0,1) as maintenance,(SELECT mess_bill.mess_bill FROM mess_bill WHERE admission_id=admission.admission_id AND charge_type='Total Charges' AND status='Active' AND mess_bill.date BETWEEN '$fmonth' and '$tmonth' limit 0,1) as totcharges,(SELECT mess_bill.mess_bill FROM mess_bill WHERE admission_id=admission.admission_id AND charge_type='Penalty' AND status='Active' AND mess_bill.date BETWEEN '$fmonth' and '$tmonth' limit 0,1) as penalty FROM `admission` left join hosteller on admission.hostellerid=hosteller.hostellerid where  admission.hostellerid='" . $_POST['hostellerid'] . "' and admission.status='Active'";
		$qsql = mysqli_query($con,$sql);
		echo mysqli_error($con);
		while($rs = mysqli_fetch_array($qsql))
		{
			$sqlbilling = "SELECT * FROM billing where admission_id='$rs[admission_id]' AND bill_type='Mess bill' AND status='Active' AND particulars='$_GET[month]'";
			$qsqlbilling = mysqli_query($con,$sqlbilling);
			$rsbilling = mysqli_fetch_array($qsqlbilling);			
			$effectiveDate = date('10-M-Y', strtotime("+1 month", strtotime($_GET['month'])));
			$effectiveDate1 = date('Y-m-10', strtotime("+1 month", strtotime($_GET['month'])));			
			$days = getWorkingDays($effectiveDate1,$dt);			
			echo json_encode($rs);
		}
	}
}
?>
<?php
if(isset($_POST['load_attendance_detail']))
{
	if(isset($_POST['monyr']))
	{
	$_GET['month'] = $_POST['monyr'];
	}
	else
	{
	$_GET['month'] = date('Y-m');
	}
	$fmonth = $_GET['month']."-01";
	$tmonth = $_GET['month']."-31";
	$noofdaysinmonth = date("t",strtotime($_GET['month']));
	$dt = date("Y-m-d");
	$sql ="SELECT * FROM `admission` left join hosteller on admission.hostellerid=hosteller.hostellerid LEFT JOIN room ON room.room_id=admission.room_id where '$dt' BETWEEN admission.start_date AND admission.end_date AND admission.status='Active'";
	if(isset($_POST['hostellerid']))
	{
			$sql = $sql . " AND hosteller.hostellerid='" . $_POST['hostellerid'] . "' ";
	}
	//echo $sql;
	$qsql =mysqli_query($con,$sql);
	while($rs = mysqli_fetch_array($qsql))
	{
		$p=1;
		$a=1;
		for($i=1; $i<=$noofdaysinmonth; $i++)	
		{
			$attdt = $_GET['month'] . "-" . $i;
			$sqlatt = "SELECT * FROM attendance where attdate='$attdt' AND admission_id='$rs[0]' Order by attendanceid DESC";
			$qsqlatt = mysqli_query($con,$sqlatt);
			$rsatt = mysqli_fetch_array($qsqlatt);
			echo json_encode(array('attdate' => $attdt, 'status' => $rsatt));
		}
	}
}
?>
