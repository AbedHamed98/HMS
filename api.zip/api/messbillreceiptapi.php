<?php
include("headerapi.php");
$fmonth = $_POST['month']."-01";
$tmonth = $_POST['month']."-31";
$sql ="SELECT admission.admission_id, hosteller.name, hosteller.hostellertype,(SELECT mess_bill.mess_bill FROM mess_bill WHERE admission_id=admission.admission_id AND charge_type='Room Rent' AND status='Active' AND mess_bill.date BETWEEN '$fmonth' and '$tmonth' AND mess_bill.admission_id='$_POST[billid]' ) as roomrent,(SELECT mess_bill.mess_bill FROM mess_bill WHERE admission_id=admission.admission_id AND charge_type='Mess Bill' AND status='Active' AND mess_bill.date BETWEEN '$fmonth' and '$tmonth' AND mess_bill.admission_id='$_POST[billid]') as messbill,(SELECT mess_bill.mess_bill FROM mess_bill WHERE admission_id=admission.admission_id AND charge_type='Water Electricity' AND status='Active' AND mess_bill.date BETWEEN '$fmonth' and '$tmonth' AND mess_bill.admission_id='$_POST[billid]') as waterelectricity,(SELECT mess_bill.mess_bill FROM mess_bill WHERE admission_id=admission.admission_id AND charge_type='Maintenance' AND status='Active' AND mess_bill.date BETWEEN '$fmonth' and '$tmonth' AND mess_bill.admission_id='$_POST[billid]') as maintenance,(SELECT mess_bill.mess_bill FROM mess_bill WHERE admission_id=admission.admission_id AND charge_type='Total Charges' AND status='Active' AND mess_bill.date BETWEEN '$fmonth' and '$tmonth' AND mess_bill.admission_id='$_POST[billid]') as totcharges, (SELECT mess_bill.mess_bill FROM mess_bill WHERE admission_id=admission.admission_id AND charge_type='Penalty' AND status='Active' AND mess_bill.date BETWEEN '$fmonth' and '$tmonth') as penalty FROM `admission` left join hosteller on admission.hostellerid=hosteller.hostellerid where admission.status='Active' AND admission.admission_id='$_POST[billid]'";
$qsql = mysqli_query($con,$sql);
$rs = mysqli_fetch_array($qsql);
$sqlbilling = "SELECT * FROM billing where admission_id='$rs[admission_id]' AND bill_type='Mess bill' AND status='Active' AND particulars='$_POST[month]'";
$qsqlbilling = mysqli_query($con,$sqlbilling);
$rsbilling = mysqli_fetch_array($qsqlbilling);
echo json_encode(array('rec' => $rs, 'rsbilling' => $rsbilling));
?>