<?php
include("headerapi.php");
$sql ="SELECT  * FROM feedback LEFT JOIN hosteller ON feedback.hostellerid=hosteller.hostellerid ";
$qsql = mysqli_query($con,$sql);
	while($rs = mysqli_fetch_array($qsql))
{
	$arrec[] = $rs;
}
echo json_encode($arrec);
?>