<?php
include("headerapi.php");

	$sql ="SELECT  * from reply LEFT JOIN employee ON reply.emp_id=employee.emp_id WHERE 0=0";	
	if(isset($_POST['hostellerid']))
	{
		$sql = $sql . " AND reply.hostellerid='$_POST[hostellerid]'";
	}
	$qsql = mysqli_query($con,$sql);
	$rs = mysqli_fetch_array($qsql);
	echo json_encode($rs);
	
	?>