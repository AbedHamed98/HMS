<?php
include("headerapi.php");
if(isset($_POST['submit']))
{
	$dttime = date("Y-m-d H:i:s");
	$sql = "INSERT INTO feedback(hostellerid,feedbackdttime,feedbacksubject,feedbackmessage) VALUES('$_POST[hostellerid]','$dttime','$_POST[feedbacksubject]','$_POST[feedbackmessage]')";
	$qsql = mysqli_query($con,$sql);
	echo mysqli_error($con);
	if(mysqli_affected_rows($con) ==1 )
	{
		echo 1;
	}
}
?>