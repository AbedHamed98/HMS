<?php
include("headerapi.php");
if(isset($_POST['submit']))
{
	if(isset($_POST['editid']))
	{
	$sql ="UPDATE blocks SET block_name='$_POST[block_name]',description='$_POST[description]',status='$_POST[status]' WHERE  block_id='" . $_POST['editid'] . "'";
		$qsql = mysqli_query($con,$sql);
		if(mysqli_affected_rows($con) ==1 )
		{
		                     			echo json_encode(1);

		} else{
		                     			echo json_encode(0);
		}
	}
	else
	{
	$sql = "INSERT INTO blocks(block_name,description,status)VALUES('$_POST[block_name]','$_POST[description]','$_POST[status]')";
	$qsql = mysqli_query($con,$sql);
	if(mysqli_affected_rows($con) ==1 )
	{
				                     			echo json_encode(1);

	}
	else
	{
		                     			echo json_encode(0);
	}
}
}
if(isset($_POST['viewguestid']))
{
	$sqledit = "SELECT * FROM blocks WHERE block_id='" . $_POST['viewguestid'] . "'";
	$qsqledit = mysqli_query($con,$sqledit);
	$rsedit = mysqli_fetch_array($qsqledit);
		echo json_encode($rsedit);

}
?>