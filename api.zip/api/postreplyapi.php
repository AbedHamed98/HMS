<?php
include("headerapi.php");
if(isset($_POST['submit']))
{
	if(isset($_POST[reply_id]))
	{
		$emp = '36';
		$dtt = date("Y-m-d H:i:s");
	$sql = "INSERT INTO reply (emp_id,replydttime,hostellerid,replysubject,replymessage) VALUES('$_POST[emp_id]','$dtt','$_POST[hostellerid]','$_POST[replysubject]','$_POST[replymessage]')";
	$qsql = mysqli_query($con,$sql);
	if(mysqli_affected_rows($con) ==1 )
		
		{
		                     			echo json_encode(1);

		} else{
		                     			echo json_encode(0);
		}
	}
	else
	{
		$emp = '36';
		$dtt = date("Y-m-d H:i:s");
	$sql ="UPDATE reply SET replydttime='$dtt',emp_id='$_POST[emp_id]',hostellerid='$_POST[hostellerid]',replysubject='$_POST[replysubject]' , replymessage='$_POST[replymessage]' WHERE  reply_id='$_POST[reply_id]'";
		$qsql = mysqli_query($con,$sql);
		if(mysqli_affected_rows($con) ==1 )
	{
				                     			echo json_encode(1);

	}
	else
	{
		                     			echo json_encode(0);
	}
}
}
if(isset($_POST['viewguestid']))
{
	$sqledit = "SELECT * FROM feedback , employee WHERE feedback_id='" . $_POST['viewguestid'] . "'";
	$qsqledit = mysqli_query($con,$sqledit);
	$rsedit = mysqli_fetch_array($qsqledit);
		echo json_encode($rsedit);

}
?>