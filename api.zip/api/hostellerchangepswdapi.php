<?php
include("headerapi.php");
if(isset($_POST['UpdatePassword']))
{
	$newhash = password_hash($_POST['password'], PASSWORD_DEFAULT);

	$sql = "UPDATE hosteller SET password='$_POST[npassword]' WHERE hostellerid='$_POST[hostellerid]' ";
	$qsql = mysqli_query($con,$sql);
	echo mysqli_error($con);
	if(mysqli_affected_rows($con) ==1 )
	{
		echo json_encode(1);	
	}
	else
	{
		echo json_encode(0);
	}
}
?>