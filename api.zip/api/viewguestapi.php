<?php
include("headerapi.php");
	$sql ="SELECT * FROM guest";
$qsql = mysqli_query($con,$sql);
while($rs = mysqli_fetch_array($qsql))
{
	$arrec[] = $rs;
}
echo json_encode($arrec);
?>