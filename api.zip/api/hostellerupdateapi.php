<?php
include("headerapi.php");
if(isset($_POST['submit']))
{
	//Update statement starts here
	$sql ="UPDATE hosteller SET name='$_POST[name]',emailid='$_POST[emailid]',status='$_POST[status]' WHERE  hostellerid='$_POST[hostellerid]'";
	$qsql = mysqli_query($con,$sql);
	if(mysqli_affected_rows($con) ==1 )
	{
	echo json_encode(1);
	}
	else
	{
	echo json_encode(0);
	}
	//Update statement ends here		
}
?>