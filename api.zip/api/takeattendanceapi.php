

<?php
include("headerapi.php");
if(isset($_POST['submit']))
{
	if(isset($_POST[attendanceid]))
	{
			
	$dttime = date("Y-m-d");

	$sql ="UPDATE attendance SET attdate='$dttime',attendancestatus='$_POST[attendancestatus]' WHERE  attendanceid='$_POST[attendanceid]'";
		$qsql = mysqli_query($con,$sql);
		if(mysqli_affected_rows($con) ==1 )
		{
		                     			echo json_encode(1);

		} else{
		                     			echo json_encode(0);
		}
	
	}
	else
	{
			$dttime = date("Y-m-d");
	$sql = "INSERT INTO attendance(admission_id,attdate,attendancestatus) VALUES('$_POST[admission_id]','$dttime','$_POST[attendancestatus]')";
	$qsql = mysqli_query($con,$sql);
	if(mysqli_affected_rows($con) ==1 )
	{
				                     			echo json_encode(1);

	}
	else
	{
		                     			echo json_encode(0);
	}	
}
}
if(isset($_POST['viewguestid']))
{
	$sqledit = "SELECT * FROM admission LEFT JOIN hosteller ON admission.hostellerid=hosteller.hostellerid LEFT JOIN room ON room.room_id=admission.room_id WHERE admission.status='Active' AND admission.admission_id='" . $_POST['viewguestid'] . "'";
	$qsqledit = mysqli_query($con,$sqledit);
	$rsedit = mysqli_fetch_array($qsqledit);
		echo json_encode($rsedit);

}
?>