<?php
include("headerapi.php");
if(isset($_POST['viewguestid']))
{
$sqledit = "SELECT * FROM guestbilling LEFT JOIN guest ON guestbilling.guestid = guest.guestid WHERE guestbilling.guestid = '" . $_POST['viewguestid'] . "'";
$qsqledit = mysqli_query($con,$sqledit);
	$rsguestfees_structure = mysqli_fetch_array($qsqledit);
	echo json_encode($rsguestfees_structure);}
?>