<?php
include("headerapi.php");
if(isset($_POST['btnpayment']))
{
	$particulars = array($_POST['bookingfrom'],$_POST['bookingto'],$_POST['noofdays'],$_POST['visitreason'],$_POST['comment'],$_POST['costperday'],$_POST['totcost'],$_POST['cardholder'], $_POST['paymenttype'], $_POST['cardnumber'],$_POST['cvvnumber'],$_POST['expirydate']);
	$particularsarr = serialize($particulars);
	$sqlbillingApproved ="SELECT * FROM guestbilling LEFT JOIN guest ON guestbilling.guestid=guest.guestid WHERE guestbilling.guestid='$_POST[guestid]' and guestbilling.status='Approved'";
	$qsqlbillingApproved = mysqli_query($con,$sqlbillingApproved);
	$rsbillingApproved = mysqli_fetch_array($qsqlbillingApproved);
	$dt = date("Y-m-d");
	$sql = "UPDATE guestbilling SET paid_amt='$_POST[totcost]',paid_date='$dt',payment_type='$_POST[paymenttype]',status='Paid',particulars='$particularsarr' WHERE billid='$rsbillingApproved[0]'";
	$qsql = mysqli_query($con,$sql);
	$billid=$rsbillingApproved[0];
	echo json_encode($billid);
}
if(isset($_POST['btnbook']))
{
	//##################
	$sql ="UPDATE guest SET visitreason='$_POST[visitreason]',comment='$_POST[comment]',fromdate='$_POST[fromdate]',todate='$_POST[todate]' WHERE  guestid='$_POST[guestid]'";
	$qsql = mysqli_query($con,$sql);
	//##################
	$now = strtotime($_POST['todate']); // or your date as well
	$your_date = strtotime($_POST['fromdate']);
	$datediff = $now - $your_date;
	$nodays =  round($datediff / (60 * 60 * 24)) + 1;
	//##################
	$particulars = array($_POST['fromdate'],$_POST['todate'],$nodays,$_POST['visitreason'],$_POST['comment']);
	$particularsarr = serialize($particulars);
	//##################	
	$sql = "INSERT INTO guestbilling(guestid,bill_type,status,particulars)VALUES('$_POST[guestid]','Guest Payment','Pending','$particularsarr')";
	$qsql = mysqli_query($con,$sql);
	echo mysqli_error($con);
	//##################
	echo json_encode(1);
	//##################
}
if(isset($_POST['viewpendingbooking']))
{
$sqlbilling ="SELECT * FROM guestbilling LEFT JOIN guest ON guestbilling.guestid=guest.guestid WHERE guestbilling.guestid='$_POST[guestid]' and guestbilling.status='Pending'";
$qsqlbilling = mysqli_query($con,$sqlbilling);
echo mysqli_error($con);
$rsbilling = mysqli_fetch_array($qsqlbilling);
echo json_encode($rsbilling);
}
if(isset($_POST['viewApprovedbooking']))
{
$sqlbillingApproved ="SELECT * FROM guestbilling LEFT JOIN guest ON guestbilling.guestid=guest.guestid WHERE guestbilling.guestid='$_POST[guestid]' and guestbilling.status='Approved'";
$qsqlbillingApproved = mysqli_query($con,$sqlbillingApproved);
echo mysqli_error($con);
$rsbillingApproved = mysqli_fetch_array($qsqlbillingApproved);
echo json_encode($rsbillingApproved);
}
?>