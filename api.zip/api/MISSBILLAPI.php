<?php
include("header2.php");
if(isset($_POST[submit]))
{
	$sql = "INSERT INTO mess_bill(admission_id,charge_type,date,mess_bill,note,status) VALUES('$_POST[admission_id]','$_POST[charge_type]','$_POST[date]','$_POST[mess_bill]','$_POST[note]','$_POST[status]')";
	$qsql = mysqli_query($con,$sql);
	if(mysqli_affected_rows($con) ==1 )
	{
						                     			echo json_encode(1);

	}
	else
	{
				                     			echo json_encode(0);
	}
}
?>