<?php
include("headerapi.php");
if(isset($_POST['submit']))
{
	//Update statement starts here
	$sql ="UPDATE admission SET food_type='$_POST[food_type]' WHERE  admission_id='$_POST[admission_id]'";
	$qsql = mysqli_query($con,$sql);
	if(mysqli_affected_rows($con) ==1 )
	{
	echo json_encode(1);
	}
	else
	{
	echo json_encode(0);
	}
	//Update statement ends here		
}
?>