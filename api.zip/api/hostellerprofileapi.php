<?php
include("headerapi.php");
if(isset($_POST['submit']))
{
	//Update statement starts here
	$sql ="UPDATE hosteller SET hostellertype='$_POST[hostellertype]',name='$_POST[name]',emailid='$_POST[emailid]',dob='$_POST[dob]',father_name='$_POST[father_name]',mother_name='$_POST[mother_name]',address='$_POST[address]',contact_no='$_POST[contact_no]' WHERE hostellerid='$_POST[hostellerid]'";
	$qsql = mysqli_query($con,$sql);
	if(mysqli_affected_rows($con) ==1 )
	{
		echo json_encode(1);
	}
	else
	{
		echo json_encode(0);
	}
	//Update statement ends here		
}
if(isset($_POST['viewhostellerid']))
{
	$sqledit = "SELECT * FROM  hosteller WHERE hostellerid='$_POST[viewhostellerid]'";
	$qsqledit = mysqli_query($con,$sqledit);
	$rsedit = mysqli_fetch_array($qsqledit);
}
?>