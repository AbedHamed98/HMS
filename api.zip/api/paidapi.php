<?php
include("headerapi.php");
	$sql ="SELECT * FROM guestbilling LEFT JOIN guest ON guestbilling.guestid=guest.guestid WHERE guestbilling.status='Paid' AND guestbilling.bill_type='Guest Payment'";
$qsql = mysqli_query($con,$sql);
while($rs = mysqli_fetch_array($qsql))
{
	$arrec[] = $rs;
}
echo json_encode($arrec);

?>